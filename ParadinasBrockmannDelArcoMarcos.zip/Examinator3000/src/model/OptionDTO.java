package model;

public class OptionDTO {
    public String text;
    public String rationale;
    public boolean correct;
}
